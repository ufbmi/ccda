UPDATE `questions` SET
`id` = '156',
`sections_id` = '21',
`next_questions_id` = NULL,
`previous_questions_id` = NULL,
`is_required` = '0',
`sort_order` = '1',
`created_at` = '2015-06-12 19:02:47',
`updated_at` = '0000-00-00 00:00:00',
`deleted_at` = '2015-07-24 10:29:26'
WHERE `id` = '136';

UPDATE `questions` SET
`id` = '156',
`sections_id` = '21',
`next_questions_id` = NULL,
`previous_questions_id` = NULL,
`is_required` = '0',
`sort_order` = '1',
`created_at` = '2015-06-12 19:02:47',
`updated_at` = '0000-00-00 00:00:00',
`deleted_at` = '2015-07-24 10:29:26'
WHERE `id` = '156';

UPDATE `questions` SET
`id` = '156',
`sections_id` = '21',
`next_questions_id` = NULL,
`previous_questions_id` = NULL,
`is_required` = '0',
`sort_order` = '1',
`created_at` = '2015-06-12 19:02:47',
`updated_at` = '0000-00-00 00:00:00',
`deleted_at` = '2015-07-24 10:29:26'
WHERE `id` = '176';
