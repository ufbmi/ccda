DELETE FROM `preferences_text`
WHERE `sections_id` >= '21' AND `sections_id` <= '42' AND ((`id` = '991') OR (`id` = '2151') OR (`id` = '992') OR (`id` = '2152') OR (`id` = '993') OR (`id` = '2153') OR (`id` = '994') OR (`id` = '2154') OR (`id` = '995') OR (`id` = '2155') OR (`id` = '996') OR (`id` = '2156') OR (`id` = '997') OR (`id` = '2157') OR (`id` = '1218') OR (`id` = '2378'));
