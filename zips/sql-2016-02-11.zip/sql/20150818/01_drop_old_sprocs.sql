DROP PROCEDURE `getProjectData`;
DROP PROCEDURE `getQuestionsCountBySectionsId`;
DROP PROCEDURE `getQuestionDetailsByQuestionsId`;
DROP PROCEDURE `insertQuestionStep_01`;

DROP PROCEDURE `getProjectsByProjectsId`;

DROP PROCEDURE `getFormsByFormsId`;
DROP PROCEDURE `getFormsByProjectsId`;

DROP PROCEDURE `getSectionsBySectionsId`;
DROP PROCEDURE `getSectionsByFormsId`;

DROP PROCEDURE `getSectionsBySectionsId`;
DROP PROCEDURE `getSectionsByFormsId`;

DROP PROCEDURE `getQuestionsByQuestionsId`;
DROP PROCEDURE `getQuestionsBySectionsId`;

DROP PROCEDURE `getAnswersByAnswersId`;
DROP PROCEDURE `getAnswersByQuestionsId`;
