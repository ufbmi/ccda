INSERT INTO `lu_types` (`value`, `parameter`, `category`)
VALUES ('checkbox', 1, 6);
