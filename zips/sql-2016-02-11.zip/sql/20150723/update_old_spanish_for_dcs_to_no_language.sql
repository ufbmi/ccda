UPDATE `preferences_text` SET
`languages_id` = NULL
WHERE ((`id` = '2486') OR (`id` = '2485') OR (`id` = '2484') OR (`id` = '2483') OR (`id` = '2482') OR (`id` = '2481') OR (`id` = '2480') OR (`id` = '2479') OR (`id` = '2478') OR (`id` = '2477') OR (`id` = '2476'));
