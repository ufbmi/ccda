INSERT INTO `preferences_text` (`id`, `languages_id`, `title`, `description`, `instructions`, `placeholder`, `default`, `sites_id`, `projects_id`, `forms_id`, `sections_id`, `questions_id`, `answers_id`) VALUES
(NULL,	2,	'Do you feel sure about what to choose? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	222,	NULL),
(NULL,	2,	'Are you clear about the best choice for you? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	221,	NULL),
(NULL,	2,	'¿Ha recibido suficientes consejos para elegir una opción?',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	220,	NULL),
(NULL,	2,	'¿Está decidiendo sin ninguna presión de otros?',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	219,	NULL),
(NULL,	2,	'¿Cuenta con suficiente apoyo de otros para elegir una opción?',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	218,	NULL),
(NULL,	2,	'Are you clear about which risks and side effects matter most to you? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	217,	NULL),
(NULL,	2,	'Are you clear about which benefits matter most to you? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	216,	NULL),
(NULL,	2,	'Do you know the risks and side effects of each option? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	215,	NULL),
(NULL,	2,	'Do you know the benefits of each option? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	214,	NULL),
(NULL,	2,	'Do you know which options are available to you? [sic]',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	213,	NULL),
(NULL,	2,	'',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	212,	NULL);
