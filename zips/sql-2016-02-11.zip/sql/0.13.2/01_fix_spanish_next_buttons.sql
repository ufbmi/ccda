UPDATE `preferences_text` SET `placeholder` = 'Siguiente', `default` = 'Anterior' WHERE `id` = '1294';
UPDATE `preferences_text` SET `placeholder` = 'Siguiente', `default` = 'Anterior' WHERE `id` = '1688';
UPDATE `preferences_text` SET `placeholder` = 'Siguiente', `default` = '' WHERE `id` = '1930';
UPDATE `preferences_text` SET `placeholder` = 'Hecho', `default` = '' WHERE `id` = '2520';
UPDATE `preferences_text` SET `placeholder` = 'Siguiente', `default` = '' WHERE `id` = '2522';
UPDATE `preferences_text` SET `placeholder` = 'Siguiente', `default` = '' WHERE `id` = '2952';
