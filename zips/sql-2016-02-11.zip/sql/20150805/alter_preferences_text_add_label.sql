ALTER TABLE `preferences_text`
ADD `object_label` text NOT NULL AFTER `default`;
