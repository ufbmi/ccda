UPDATE `answers` SET
`questions_id` = '212'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1279') OR (`id` = '1290') OR (`id` = '1301'));

UPDATE `answers` SET
`questions_id` = '213'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1280') OR (`id` = '1291') OR (`id` = '1302'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1281') OR (`id` = '1292') OR (`id` = '1303'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1282') OR (`id` = '1293') OR (`id` = '1304'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1283') OR (`id` = '1294') OR (`id` = '1305'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1284') OR (`id` = '1295') OR (`id` = '1306'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1285') OR (`id` = '1296') OR (`id` = '1307'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1286') OR (`id` = '1297') OR (`id` = '1308'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1287') OR (`id` = '1298') OR (`id` = '1309'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1288') OR (`id` = '1299') OR (`id` = '1310'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1289') OR (`id` = '1300') OR (`id` = '1311'));
