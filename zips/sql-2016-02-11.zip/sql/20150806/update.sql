INSERT INTO `answers` (`id`, `questions_id`, `next_answers_id`, `previous_answers_id`, `previous_questions_id`, `next_questions_id`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(NULL,	212,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:14:18',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	212,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	212,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	213,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	213,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	213,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	214,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	214,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	214,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	215,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	215,	NULL,	NULL,	NULL,	NULL,	0,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	215,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	216,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	216,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	216,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	217,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	217,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	217,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	218,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	218,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	218,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	219,	NULL,	NULL,	NULL,	NULL,	1,	'2015-07-22 14:14:18',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	219,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	219,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	220,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	220,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	220,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	221,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	221,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	221,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	222,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	222,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:15:14',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(NULL,	222,	NULL,	NULL,	NULL,	NULL,	2,	'2015-07-22 14:14:18',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

INSERT INTO `preferences_text` (`id`, `languages_id`, `title`, `description`, `instructions`, `placeholder`, `default`, `object_label`, `sites_id`, `projects_id`, `forms_id`, `sections_id`, `questions_id`, `answers_id`) VALUES
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1279),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1280),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1281),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1282),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1283),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1284),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1285),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1286),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1287),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1288),
(NULL,	2,	'Sí',	'0',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1289),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1290),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1301),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1291),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1302),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1292),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1303),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1293),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1304),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1294),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1305),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1295),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1306),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1296),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1307),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1297),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1308),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1298),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1309),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1299),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1310),
(NULL,	2,	'No sé',	'2',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1300),
(NULL,	2,	'No',	'4',	'',	'',	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	1311);

UPDATE `preferences_text` SET
`id` = '2547',
`languages_id` = '2',
`title` = '¿Sabe cuál es la mejor opción para usted?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '213',
`answers_id` = NULL
WHERE `id` = '2547';


UPDATE `preferences_text` SET
`id` = '2546',
`languages_id` = '2',
`title` = '¿Está segura de lo que va a hacer?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '214',
`answers_id` = NULL
WHERE `id` = '2546';


UPDATE `preferences_text` SET
`id` = '2545',
`languages_id` = '2',
`title` = '¿Sabe cuáles son las opciones?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '215',
`answers_id` = NULL
WHERE `id` = '2545';


UPDATE `preferences_text` SET
`id` = '2544',
`languages_id` = '2',
`title` = '¿Sabe que es lo bueno de cada opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '216',
`answers_id` = NULL
WHERE `id` = '2544';


UPDATE `preferences_text` SET
`id` = '2543',
`languages_id` = '2',
`title` = '¿Sabe que es lo malo de cada opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '217',
`answers_id` = NULL
WHERE `id` = '2543';


UPDATE `preferences_text` SET
`id` = '2542',
`languages_id` = '2',
`title` = '¿Tiene claro que es lo que mas le gusta de cada opcón?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '218',
`answers_id` = NULL
WHERE `id` = '2542';


UPDATE `preferences_text` SET
`id` = '2541',
`languages_id` = '2',
`title` = '¿Tiene claro que es lo que menos le gusta de cada opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '219',
`answers_id` = NULL
WHERE `id` = '2541';


UPDATE `preferences_text` SET
`id` = '2540',
`languages_id` = '2',
`title` = '¿Cuenta con suficiente apoyo de otros para elegir una opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '220',
`answers_id` = NULL
WHERE `id` = '2540';


UPDATE `preferences_text` SET
`id` = '2539',
`languages_id` = '2',
`title` = '¿Está decidiendo sin ninguna presión de otros?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '221',
`answers_id` = NULL
WHERE `id` = '2539';


UPDATE `preferences_text` SET
`id` = '2538',
`languages_id` = '2',
`title` = '¿Ha recibido suficientes consejos para elegir una opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '222',
`answers_id` = NULL
WHERE `id` = '2538';

UPDATE `answers` SET
`questions_id` = '212'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1279') OR (`id` = '1290') OR (`id` = '1301'));

UPDATE `answers` SET
`questions_id` = '213'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1280') OR (`id` = '1291') OR (`id` = '1302'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1281') OR (`id` = '1292') OR (`id` = '1303'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1282') OR (`id` = '1293') OR (`id` = '1304'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1283') OR (`id` = '1294') OR (`id` = '1305'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1284') OR (`id` = '1295') OR (`id` = '1306'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1285') OR (`id` = '1296') OR (`id` = '1307'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1286') OR (`id` = '1297') OR (`id` = '1308'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1287') OR (`id` = '1298') OR (`id` = '1309'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1288') OR (`id` = '1299') OR (`id` = '1310'));

UPDATE `answers` SET
`questions_id` = '214'
WHERE `id` >= '1279' AND `id` <= '1311' AND ((`id` = '1289') OR (`id` = '1300') OR (`id` = '1311'));

UPDATE `ccdaa`.`preferences_text` SET `title`='Información basica' WHERE `id`='1229';
UPDATE `ccdaa`.`preferences_text` SET `title`='Información de cancer de colon y recto', `description`='Que es el cancer de colon y porque es importante hacerse la prueba' WHERE `id`='1231';
UPDATE `ccdaa`.`preferences_text` SET `title`='Conocimientos' WHERE `id`='1286';
UPDATE `ccdaa`.`preferences_text` SET `title`='Barreras' WHERE `id`='1287';
UPDATE `ccdaa`.`preferences_text` SET `title`='Beneficios' WHERE `id`='1288';
UPDATE `ccdaa`.`preferences_text` SET `title`='Percepción de Suceptibilidad' WHERE `id`='1289';
UPDATE `ccdaa`.`preferences_text` SET `title`='Intenciones', `description`='Sección F.' WHERE `id`='1290';
UPDATE `ccdaa`.`preferences_text` SET `title`='Autosuficiencia', `description`='Sección G.' WHERE `id`='1291';
UPDATE `ccdaa`.`preferences_text` SET `title`='Procesos de Cambio', `description`='Sección H.' WHERE `id`='1292';
UPDATE `ccdaa`.`preferences_text` SET `title`='Toma de Decisiones', `description`='Sección I.' WHERE `id`='1293';
UPDATE `ccdaa`.`preferences_text` SET `title`='Aculturación' WHERE `id`='1294';
UPDATE `ccdaa`.`preferences_text` SET `title`='Que  prueba hacerme', `description`='Como debo decidir que prueba hacerme?' WHERE `id`='1683';
UPDATE `ccdaa`.`preferences_text` SET `title`='Video segmento 4', `description`='Descripción de la prueba FIT' WHERE `id`='1684';
UPDATE `ccdaa`.`preferences_text` SET `title`='Descripción de la prueba inmunoquímica fecal' WHERE `id`='1685';
UPDATE `ccdaa`.`preferences_text` SET `title`='Descripción de la colonoscopía' WHERE `id`='1686';
UPDATE `ccdaa`.`preferences_text` SET `title`='Video segmento 6', `description`='Descripción de la Sigmoidoscopía Flexible' WHERE `id`='1687';
UPDATE `ccdaa`.`preferences_text` SET `title`='Descripción de la Sigmoidoscopía Flexible' WHERE `id`='1688';
UPDATE `ccdaa`.`preferences_text` SET `title`='Preferencias del paciente en base  a los atributos de la prueba' WHERE `id`='1689';
UPDATE `ccdaa`.`preferences_text` SET `title`='Video segmento 1-3' WHERE `id`='1690';
UPDATE `ccdaa`.`preferences_text` SET `title`='Video segmento 5', `description`='Descripción de la colonoscopía' WHERE `id`='1691';
UPDATE `ccdaa`.`preferences_text` SET `title`='Video segmento 3' WHERE `id`='1692';
UPDATE `ccdaa`.`preferences_text` SET `title`='Evaluación de Usabilidad' WHERE `id`='2379';
UPDATE `ccdaa`.`preferences_text` SET `title`='Preguntas finales' WHERE `id`='2381';
UPDATE `ccdaa`.`preferences_text` SET `title`='Fatalismo' WHERE `id`='1232';

UPDATE `ccdaa`.`preferences_text` SET `description`='The entire colon is examined with this test' WHERE `id`='793';
UPDATE `ccdaa`.`preferences_text` SET `description`='The average cost before insurance is  $800 - $1600\rUnder the Patient Prevention and Affordable Care Act, all health plans are required to cover preventive screening tests, like colonoscopies. However, you may still owe a copay or deductible.' WHERE `id`='632';
UPDATE `ccdaa`.`preferences_text` SET `description`='The average cost before insurance is : $500 - $750\rUnder the Patient Prevention and Affordable Care Act, all health plans are required to cover preventive screening tests, like flexible sigmoidoscopy. However, you may still owe a copay or deductible.' WHERE `id`='1053';
UPDATE `ccdaa`.`preferences_text` SET `description`='The average cost before insurance is : $500 - $750\rUnder the Patient Prevention and Affordable Care Act, all health plans are required to cover preventive screening tests, like flexible sigmoidoscopy. However, you may still owe a copay or deductible.' WHERE `id`='2551';

UPDATE `ccdaa`.`preferences_text` SET `description`='Section F.' WHERE `id`='82';
UPDATE `ccdaa`.`preferences_text` SET `description`='Section G.' WHERE `id`='83';
UPDATE `ccdaa`.`preferences_text` SET `description`='Section H.' WHERE `id`='84';
UPDATE `ccdaa`.`preferences_text` SET `description`='Section I.' WHERE `id`='85';
UPDATE `ccdaa`.`preferences_text` SET `description`='Section J.' WHERE `id`='86';

UPDATE `preferences_text` SET
`id` = '2421',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1005'
WHERE `id` = '2421';

UPDATE `preferences_text` SET
`id` = '2422',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1006'
WHERE `id` = '2422';

UPDATE `preferences_text` SET
`id` = '2423',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1007'
WHERE `id` = '2423';

UPDATE `preferences_text` SET
`id` = '2424',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1008'
WHERE `id` = '2424';

UPDATE `preferences_text` SET
`id` = '2425',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1009'
WHERE `id` = '2425';

UPDATE `preferences_text` SET
`id` = '2426',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1010'
WHERE `id` = '2426';

UPDATE `preferences_text` SET
`id` = '2427',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1011'
WHERE `id` = '2427';

UPDATE `preferences_text` SET
`id` = '2428',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1012'
WHERE `id` = '2428';

UPDATE `preferences_text` SET
`id` = '2429',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1013'
WHERE `id` = '2429';

UPDATE `preferences_text` SET
`id` = '2430',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1014'
WHERE `id` = '2430';

UPDATE `preferences_text` SET
`id` = '2431',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1015'
WHERE `id` = '2431';
