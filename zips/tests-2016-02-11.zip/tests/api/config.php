<?php
  $config = array(
    'phpunit_xml_path' => './webPhpunit.xml',
    'custom_php_root' => 'LOG',
    'custom_php_tag' => 'PHPRUN'
  );
?>
