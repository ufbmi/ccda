var debug_mode = true;
var root_config = {
  "title": "DAA Testing Suite",
  "version": "0.1.0",
  "description": "DAA Testing Suite",
  "author": "CTS-IT <ctsit@ctsi.ufl.edu>, Roy Keyes <keyes@ufl.edu>",
  "copyright": "CTS-IT @ University of Florida 2015",
  "api_url": "https://vagrant1/tests/api/api.php",
  "app_name": "DAA"
};
