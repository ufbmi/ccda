
[![Build Status](https://travis-ci.org/example42/puppet-solr.png?branch=master)](https://travis-ci.org/example42/puppet-solr)
