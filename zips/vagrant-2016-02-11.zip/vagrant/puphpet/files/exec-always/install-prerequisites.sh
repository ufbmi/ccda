#!/bin/bash
# Install prerequisites for app

pip install mdat
