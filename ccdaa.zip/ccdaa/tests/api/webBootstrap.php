<?php
  include_once('AutoLoader.php');
  $AutoLoader = new AutoLoader();
  $AutoLoader->registerDirectory('../../api/v1/libs');
?>
