ALTER TABLE `responses`
DROP `updated_at`;
