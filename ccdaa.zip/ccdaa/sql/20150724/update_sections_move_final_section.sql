UPDATE `sections` SET
`id` = '34',
`forms_id` = '3',
`next_sections_id` = NULL,
`previous_sections_id` = '33',
`sort_order` = '13',
`created_at` = '2015-06-12 17:11:40',
`updated_at` = '0000-00-00 00:00:00',
`deleted_at` = '0000-00-00 00:00:00'
WHERE `id` = '34';
