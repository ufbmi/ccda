UPDATE `sections` SET
`deleted_at` = '2015-07-24 10:29:26'
WHERE `forms_id` = '3' AND ((`id` = '35') OR (`id` = '36') OR (`id` = '37') OR (`id` = '38') OR (`id` = '39') OR (`id` = '40') OR (`id` = '41') OR (`id` = '42'));
