DELETE FROM `preferences_options`
WHERE `sections_id` >= '21' AND `sections_id` <= '42' AND ((`id` = '270') OR (`id` = '271') OR (`id` = '272') OR (`id` = '273') OR (`id` = '274') OR (`id` = '275') OR (`id` = '276') OR (`id` = '277'));
