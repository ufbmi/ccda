UPDATE `preferences_text` SET `id` = '4488', `languages_id` = '2', `title` = 'No Hispano o Latino', `description` = 'not_hispanic_or_latino', `instructions` = '', `placeholder` = '', `default` = '', `object_label` = '', `sites_id` = NULL, `projects_id` = NULL, `forms_id` = NULL, `sections_id` = NULL, `questions_id` = NULL, `answers_id` = '1983' WHERE `id` IN (4488,4487,4486,4485) AND `id` = '4488';
UPDATE `preferences_text` SET `id` = '4487', `languages_id` = '1', `title` = 'Not Hispanic or Latino', `description` = 'not_hispanic_or_latino', `instructions` = '', `placeholder` = '', `default` = '', `object_label` = '', `sites_id` = NULL, `projects_id` = NULL, `forms_id` = NULL, `sections_id` = NULL, `questions_id` = NULL, `answers_id` = '1983' WHERE `id` IN (4488,4487,4486,4485) AND `id` = '4487';
UPDATE `preferences_text` SET `id` = '4486', `languages_id` = '2', `title` = 'Hispano o Latino', `description` = 'hispanic_or_latino', `instructions` = '', `placeholder` = '', `default` = '', `object_label` = '', `sites_id` = NULL, `projects_id` = NULL, `forms_id` = NULL, `sections_id` = NULL, `questions_id` = NULL, `answers_id` = '1982' WHERE `id` IN (4488,4487,4486,4485) AND `id` = '4486';
UPDATE `preferences_text` SET `id` = '4485', `languages_id` = '1', `title` = 'Hispanic or Latino', `description` = 'hispanic_or_latino', `instructions` = '', `placeholder` = '', `default` = '', `object_label` = '', `sites_id` = NULL, `projects_id` = NULL, `forms_id` = NULL, `sections_id` = NULL, `questions_id` = NULL, `answers_id` = '1982' WHERE `id` IN (4488,4487,4486,4485) AND `id` = '4485';

UPDATE `preferences_options` SET
`id` = '1043',
`lu_options_id` = '2',
`languages_id` = NULL,
`value` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '468',
`answers_id` = NULL
WHERE `id` = '1043';
