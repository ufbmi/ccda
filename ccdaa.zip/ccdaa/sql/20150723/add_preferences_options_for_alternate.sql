INSERT INTO `preferences_options` (`id`, `lu_options_id`, `languages_id`, `value`, `sites_id`, `projects_id`, `forms_id`, `sections_id`, `questions_id`) VALUES
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	222),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	221),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	220),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	219),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	218),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	217),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	216),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	215),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	214),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	213),
(NULL,	2,	NULL,	'matrix',	NULL,	NULL,	NULL,	NULL,	212);
