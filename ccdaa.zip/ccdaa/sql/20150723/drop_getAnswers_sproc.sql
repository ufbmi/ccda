DROP PROCEDURE `getAnswers`
