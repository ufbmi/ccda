INSERT INTO `preferences_types` (`id`, `lu_types_id`, `sites_id`, `projects_id`, `forms_id`, `sections_id`, `questions_id`) VALUES
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	222),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	221),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	220),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	219),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	218),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	217),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	216),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	215),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	214),
(NULL,	8,	NULL,	NULL,	NULL,	NULL,	213),
(NULL,	10,	NULL,	NULL,	NULL,	NULL,	212);
