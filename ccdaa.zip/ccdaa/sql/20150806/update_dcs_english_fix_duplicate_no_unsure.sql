UPDATE `preferences_text` SET
`id` = '2421',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1005'
WHERE `id` = '2421';

UPDATE `preferences_text` SET
`id` = '2422',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1006'
WHERE `id` = '2422';

UPDATE `preferences_text` SET
`id` = '2423',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1007'
WHERE `id` = '2423';

UPDATE `preferences_text` SET
`id` = '2424',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1008'
WHERE `id` = '2424';

UPDATE `preferences_text` SET
`id` = '2425',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1009'
WHERE `id` = '2425';

UPDATE `preferences_text` SET
`id` = '2426',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1010'
WHERE `id` = '2426';

UPDATE `preferences_text` SET
`id` = '2427',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1011'
WHERE `id` = '2427';

UPDATE `preferences_text` SET
`id` = '2428',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1012'
WHERE `id` = '2428';

UPDATE `preferences_text` SET
`id` = '2429',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1013'
WHERE `id` = '2429';

UPDATE `preferences_text` SET
`id` = '2430',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1014'
WHERE `id` = '2430';

UPDATE `preferences_text` SET
`id` = '2431',
`languages_id` = '1',
`title` = 'No',
`description` = '4',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = NULL,
`answers_id` = '1015'
WHERE `id` = '2431';
