UPDATE `preferences_text` SET
`id` = '2547',
`languages_id` = '2',
`title` = '¿Sabe cuál es la mejor opción para usted?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '213',
`answers_id` = NULL
WHERE `id` = '2547';


UPDATE `preferences_text` SET
`id` = '2546',
`languages_id` = '2',
`title` = '¿Está segura de lo que va a hacer?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '214',
`answers_id` = NULL
WHERE `id` = '2546';


UPDATE `preferences_text` SET
`id` = '2545',
`languages_id` = '2',
`title` = '¿Sabe cuáles son las opciones?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '215',
`answers_id` = NULL
WHERE `id` = '2545';


UPDATE `preferences_text` SET
`id` = '2544',
`languages_id` = '2',
`title` = '¿Sabe que es lo bueno de cada opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '216',
`answers_id` = NULL
WHERE `id` = '2544';


UPDATE `preferences_text` SET
`id` = '2543',
`languages_id` = '2',
`title` = '¿Sabe que es lo malo de cada opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '217',
`answers_id` = NULL
WHERE `id` = '2543';


UPDATE `preferences_text` SET
`id` = '2542',
`languages_id` = '2',
`title` = '¿Tiene claro que es lo que mas le gusta de cada opcón?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '218',
`answers_id` = NULL
WHERE `id` = '2542';


UPDATE `preferences_text` SET
`id` = '2541',
`languages_id` = '2',
`title` = '¿Tiene claro que es lo que menos le gusta de cada opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '219',
`answers_id` = NULL
WHERE `id` = '2541';


UPDATE `preferences_text` SET
`id` = '2540',
`languages_id` = '2',
`title` = '¿Cuenta con suficiente apoyo de otros para elegir una opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '220',
`answers_id` = NULL
WHERE `id` = '2540';


UPDATE `preferences_text` SET
`id` = '2539',
`languages_id` = '2',
`title` = '¿Está decidiendo sin ninguna presión de otros?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '221',
`answers_id` = NULL
WHERE `id` = '2539';


UPDATE `preferences_text` SET
`id` = '2538',
`languages_id` = '2',
`title` = '¿Ha recibido suficientes consejos para elegir una opción?',
`description` = '',
`instructions` = '',
`placeholder` = '',
`default` = '',
`object_label` = '',
`sites_id` = NULL,
`projects_id` = NULL,
`forms_id` = NULL,
`sections_id` = NULL,
`questions_id` = '222',
`answers_id` = NULL
WHERE `id` = '2538';
