INSERT INTO `lu_types` (`value`, `parameter`, `category`)
VALUES ('ranking', 1, 6);
