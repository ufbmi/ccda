--
-- Contents of /Users/pbc/git/ccdaa/utils/..//./sql/0.13.6/99_bump_version_number.sql
--
update forms set version='0.13.6' where 1=1;

