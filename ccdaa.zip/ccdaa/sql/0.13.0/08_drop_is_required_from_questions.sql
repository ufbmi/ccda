ALTER TABLE `questions`
DROP `is_required`;
