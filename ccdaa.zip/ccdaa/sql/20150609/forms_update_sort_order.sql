ALTER TABLE `forms` CHANGE `sort_order` `sort_order` INT(11) NOT NULL DEFAULT '0';
