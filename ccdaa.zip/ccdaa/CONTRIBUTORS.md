# CCDAA Contributors

The CCDAA Project would not be possible without the generous contributions of
our authors and contributors.

François Modave provided funding and guidance on the algorithms.  Navkiran Shokar and Silvia Flores provided survey content.

We are indebted to these people have provided contributions of code, documentation, and time to the project:

    Alex Loiacono - atloiaco@ufl.edu
    Christopher P Barnes - cpb@ufl.edu
    Nicholas Rejack - nrejack@ufl.edu
    Philip Chase - pbc@ufl.edu
    Roy Keyes - keyes@ufl.edu
    Silvia Flores - silvia.flores@ttuhsc.edu
    Taeber Rapczak - taeber@ufl.edu
