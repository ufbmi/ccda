app.directive('myGreeting', function ($rootScope, $interval, $filter, dateFilter) {
    return function (scope, element, attrs) {
      
    };
});
